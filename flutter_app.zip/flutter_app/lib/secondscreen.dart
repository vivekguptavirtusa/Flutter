import 'package:flutter/material.dart';

class SecondScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('THIS IS NEW INFO PAGE'),
        centerTitle: true,
        backgroundColor: Colors.orange,
      ),
      body: Center(
        child: Text('THIS IS NEW PAGE AFTER CLICKING BUTTON',
          style: TextStyle(
            color: Colors.grey,
            fontWeight: FontWeight.bold,),
        ),
      ),
    );
  }}