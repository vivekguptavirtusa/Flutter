import 'package:flutter/material.dart';

class Transaction extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('TRANSACTIONS'),
        centerTitle: true,
        backgroundColor: Colors.purple,
      ),
      body: Center(
        child: Column(
          children: <Widget>[
            Text(
              'NAME :- Vivek Gupta ',
              style: TextStyle(
                height: 3.0,
                fontSize: 25.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.blueGrey,
              ),
            ),
            Text(
              'Account No. :- 36987412587 ',
              style: TextStyle(
                height: 3.0,
                fontSize: 25.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.lightBlue,
              ),
            ),
            Text(
              'ACCOUNT          STATUS        BALANCE ',
              style: TextStyle(
                height: 3.0,
                fontSize: 15.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.green,
              ),
            ),
            Text(
              'AMAZON          SUCCESFUL        1,000 ',
              style: TextStyle(
                height: 3.0,
                fontSize: 15.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.deepOrangeAccent,
              ),
            ),
            Text(
              'MYNTRA          SUCCESFUL        1,563 ',
              style: TextStyle(
                height: 3.0,
                fontSize: 15.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.deepOrangeAccent,
              ),
            ),
            Text(
              'HDFC5623          SUCCESFUL        8,500 ',
              style: TextStyle(
                height: 3.0,
                fontSize: 15.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.deepOrangeAccent,
              ),
            ),
            Text(
              'PHONEPE          SUCCESFUL         700 ',
              style: TextStyle(
                height: 3.0,
                fontSize: 15.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.deepOrangeAccent,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
