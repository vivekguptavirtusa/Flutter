  import 'package:flutter/material.dart';
import 'secondscreen.dart';
import 'sharath.dart';
  import 'vivek.dart';
  import 'mukil.dart';
  import 'logout.dart';
  void main()=> runApp(MaterialApp(
    home: First(),
  ));
class First extends StatelessWidget {
  @override
  Widget build(BuildContext context){
              return Scaffold(
                appBar:AppBar(
                  title:Text('HELLO WORLD'),
                  backgroundColor:Colors.red[600],
                  centerTitle:true,
                ),
                drawer:Drawer(
                  child:ListView(
                    children: <Widget>[
                      DrawerHeader(
                        decoration:BoxDecoration(
                      gradient:LinearGradient(colors: <Color>[
                        Colors.deepOrange,
                        Colors.orangeAccent
                      ])
                  ),
                          child:Text('TEAM INFO')),
                      CustomTileList(Icons.person,'SHARATH INFO',()=>{ Navigator.push(context,
                      MaterialPageRoute(builder: (context)=>Sharath())
                      )}),
                      CustomTileList(Icons.person,'VIVEK INFO',()=>{ Navigator.push(context,
                          MaterialPageRoute(builder: (context)=>Vivek())
                      )}),
                      CustomTileList(Icons.person,'MUKIL INFO',()=>{ Navigator.push(context,
                          MaterialPageRoute(builder: (context)=>Mukil())
                      )}),
                      CustomTileList(Icons.person,'ANWAR INFO',()=>{ Navigator.push(context,
                          MaterialPageRoute(builder: (context)=>Sharath())
                      )}),
                      CustomTileList(Icons.exit_to_app,'LOGOUT',()=>{ Navigator.push(context,
                          MaterialPageRoute(builder: (context)=>logout())
                      )}),
                    ]
                  )
                ),
                body:Center(
                  //child:Image(),
                  child:Column(
                    children:<Widget>[

                    Text('I am Vivek...welcome to my flutter project using stateless widget',
                     style:TextStyle(
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2.0,
                      color: Colors.purple,),),
                    Text('WELCOME TEAM ...',
                      style:TextStyle(
                        fontSize: 30.0,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2.0,
                        color: Colors.yellow,),),
                      ],
                    ),
                ),
                floatingActionButton:FlatButton(
                  onPressed:(){
                    Navigator.push(context,
                    MaterialPageRoute(builder: (context)=>SecondScreen())
                    );
                  },
                  child:Text('click me for next page'),
                  color:Colors.green[500],
                ),
              );
  }
}

class CustomTileList extends StatelessWidget
{
  IconData icon;
  String text;
  Function onTap;

  CustomTileList(this.icon,this.text,this.onTap);
  @override
  Widget build(BuildContext context){
    return Padding(
    padding: const EdgeInsets.fromLTRB(8.0,0,8.0,0),
      child:Container(
        decoration:BoxDecoration(
          border:Border(bottom:BorderSide(color:Colors.grey))),
        child:InkWell(
         splashColor:Colors.orange,
         onTap:onTap,
          child:Container(
            height:50,
               child : Row(
                  children :<Widget>[
                 Icon(icon),
                  Text(text),
                  Icon(Icons.arrow_right)
                       ],
                     ),
                ),
        ),
    ),
    );
  }
}