import 'package:flutter/material.dart';

class Vivek extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('VIVEK DATA'),
        centerTitle: true,
        backgroundColor: Colors.purple,
      ),
      body: Center(
        child:Column(
          children:<Widget>[

            Text('NAME :- VIVEK ',
              style:TextStyle(
                fontSize: 25.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.blueGrey,),),
            Text('COMPANY :-  VIRTUSA CHENNAI ',
              style:TextStyle(
                fontSize: 25.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.lightBlue,),),
            Text('ROLE :- ASSOCIATE SOFTWARE ENGINEER ',
              style:TextStyle(
                fontSize: 25.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.green,),),
            Text('PROJECT :- HACKATHON ',
              style:TextStyle(
                fontSize: 25.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.deepOrangeAccent,),),
          ],
        ),
      ),
    );
  }}