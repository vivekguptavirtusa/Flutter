import 'package:flutter/material.dart';

class Sharath extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('SHARATH DATA'),
        centerTitle: true,
        backgroundColor: Colors.purple,
      ),
      body: Center(
        child:Column(
          children:<Widget>[

            Text('NAME :- SHARATH ',
              style:TextStyle(
                fontSize: 25.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.blueGrey,),),
            Text('COMPANY :-  VIRTUSA ',
              style:TextStyle(
                fontSize: 25.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.lightBlue,),),
            Text('ROLE :- SOFTWARE ENGINEER ',
              style:TextStyle(
                fontSize: 25.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.green,),),
            Text('PROJECT :- HACKATHON ',
              style:TextStyle(
                fontSize: 25.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.deepOrangeAccent,),),
          ],
        ),
      ),
    );
  }}