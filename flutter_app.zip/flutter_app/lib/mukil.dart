import 'package:flutter/material.dart';

class Mukil extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('MUKIL DATA'),
        centerTitle: true,
        backgroundColor: Colors.purple,
      ),
      body: Center(
        child:Column(
          children:<Widget>[

            Text('NAME :- MUKIL ',  
              style:TextStyle(
                height: 30.0,
                fontSize: 25.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                
                color: Colors.blueGrey,),),
            Text('COMPANY :-  VIRTUSA CHN ',
              style:TextStyle(
                height:30.0,
                fontSize: 25.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.lightBlue,),),
            Text('ROLE :- PROJECT MANAGER ',
              style:TextStyle(
                fontSize: 25.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.green,),),
            Text('PROJECT :- HACKATHON ',
              style:TextStyle(
                fontSize: 25.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.deepOrangeAccent,),),
          ],
        ),
      ),
    );
  }}