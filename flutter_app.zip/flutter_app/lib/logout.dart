import 'package:flutter/material.dart';

class logout extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Bank Of America'),
        centerTitle: true,
        backgroundColor: Colors.redAccent,
      ),
      body: Center(
        child: Text('YOU ARE LOGGED OUT ....  THANK YOU FOR YOUR VISIT..',
          style: TextStyle(
            color: Colors.lightGreen,
            fontWeight: FontWeight.bold,),
        ),
      ),
    );
  }}