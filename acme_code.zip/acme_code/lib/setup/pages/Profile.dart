import 'package:flutter/material.dart';

class Profile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('PROFILE INFORMATION'),
        centerTitle: true,
        backgroundColor: Colors.purple,
      ),
      body: Center(
        child:Column(
          children:<Widget>[

            Text('NAME :- VIVEK GUPTA',
              style:TextStyle(
                fontSize: 25.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.blueGrey,),),
            Text('ACCOUNT NO :- 5897325365',
              style:TextStyle(
                fontSize: 25.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.lightBlue,),),
            Text('BRANCH :- CHENNAI DLF ',
              style:TextStyle(
                fontSize: 25.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.green,),),
            Text('IFSC :- ACME6269526933',
              style:TextStyle(
                fontSize: 25.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.deepOrangeAccent,),),
          ],
        ),
      ),
    );
  }}