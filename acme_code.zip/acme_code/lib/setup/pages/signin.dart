import 'package:flutter/material.dart';
import 'package:flutter_app/setup/home.dart';
import 'package:firebase_auth/firebase_auth.dart';


class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => new _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  String _email, _password;

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar( title: Text('ACME BANK'),
        backgroundColor: Colors.red[600],
        centerTitle: true,),
      body:Container(
    decoration: BoxDecoration(
    border:Border.all(width: 1),
    image: DecorationImage(

    image:AssetImage("assets/images/login2.jpg"),


    fit: BoxFit.cover,),),
    child:  Padding(
        padding:const EdgeInsets.all(40.0),
        child:Form(
          key: _formKey,
          child: Column(
            children: <Widget>[

              TextFormField(
                validator: (input) {
                  if (input.isEmpty) {
                    return 'Provide an email';
                  }
                },
                decoration: InputDecoration(labelText: 'Email',),
                onSaved: (input) => _email = input,
              ),
              TextFormField(
                validator: (input) {
                  if (input.length < 6) {
                    return 'Longer password please';
                  }
                },
                decoration: InputDecoration(labelText: 'Password'),
                onSaved: (input) => _password = input,
                obscureText: true,
              ),
              RaisedButton(padding:const EdgeInsets.all(10.0),
                onPressed: signIn,
                child: Text('LOG IN',
                  style: TextStyle(
                    fontSize: 20.0,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2.0,
                    color: Colors.purple,
                  ), ),
              ),
            ],
          )),),),
    );
  }

  void signIn() async {
    if (_formKey.currentState.validate()) {
      //FirebaseApp.init
      _formKey.currentState.save();
      try {
        // FirebaseUser user = (await FirebaseAuth.instance
        //         .signInWithEmailAndPassword(email: _email, password: _password))
        //     .user;
        await FirebaseAuth.instance
            .signInWithEmailAndPassword(email: _email, password: _password);

        Navigator.push(
            context, MaterialPageRoute(builder: (context) => Home()));
        //   var home = Home(user: user);
        //   return home;
        // }));
      } catch (e) {
        print(e.message);
      }
    }
  }
}
