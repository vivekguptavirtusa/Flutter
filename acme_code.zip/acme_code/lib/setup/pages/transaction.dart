import 'package:flutter/material.dart';
import 'dart:convert';

class Transaction extends StatefulWidget {
  @override
  TransactionPage createState() => new TransactionPage();
}
class TransactionPage extends State<Transaction>{
  List data;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('TRANSACTIONS'),
        centerTitle: true,
        backgroundColor: Colors.purple,
      ),
      body: new Container(
        child: new Center(

          child:new FutureBuilder(
            future: DefaultAssetBundle
                .of(context)
                .loadString('load_json/transaction.json'),
            builder: (context, snapshot){
              var mydata =json.decode(snapshot.data.toString());
              return new ListView.builder(
                  itemBuilder:(BuildContext context, int index){
                    return new Card(
                      child:new Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: <Widget>[
                          new Text("Account:"+mydata[index]['account'],
                            style:TextStyle(
                              fontSize: 25.0,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 2.0,
                              color: Colors.blueGrey,),),
                          new Text("Status:"+mydata[index]['status'],
                            style:TextStyle(
                              fontSize: 25.0,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 2.0,
                              color: Colors.purpleAccent,),),
                          new Text("Amount:"+mydata[index]['amount'],
                            style:TextStyle(
                              fontSize: 25.0,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 2.0,
                              color: Colors.redAccent,),),
                          new Text("Date:"+mydata[index]['date'],
                            style:TextStyle(
                              fontSize: 25.0,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 2.0,
                              color: Colors.deepOrange,),),
                        ],
                      )
                    );
                  },
                itemCount: mydata == null ? 0 : mydata.length,
              );
            },

          ),
        ),
      ),
    );
  }
}


