import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/setup/pages/signin.dart';
import 'package:flutter_app/setup/pages/signup.dart';

class WelcomePage extends StatefulWidget {
  @override
  _WelcomePageState createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('ACME BANK'),
        backgroundColor: Colors.red[600],
        centerTitle: true,
      ),
    body: Container(

    decoration: BoxDecoration(
    border:Border.all(width: 1),
    image: DecorationImage(

    image:AssetImage("assets/images/login.jpg"),


    fit: BoxFit.cover,
    ),
    ),
    child:Column( mainAxisAlignment: MainAxisAlignment.center,
    crossAxisAlignment: CrossAxisAlignment.stretch,

    children: <Widget>[
          Padding(
      padding:const EdgeInsets.all(30.0),

         child: RaisedButton(
           padding:const EdgeInsets.all(30.0),
            onPressed: navigateToSignIn,
            child: Text('LOG IN',
              style: TextStyle(
                fontSize: 20.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.lightGreenAccent,
              ),),
            color: Colors.purpleAccent,
          ),),
    Padding(
    padding:const EdgeInsets.all(30.0),

   child: RaisedButton(
     padding:const EdgeInsets.all(30.0),
            onPressed: navigateToSignUp,
            child: Text('SIGN UP',
            style: TextStyle(
    fontSize: 20.0,
    fontWeight: FontWeight.bold,
    letterSpacing: 2.0,
    color: Colors.lightGreenAccent,
    ),),
    color: Colors.blueGrey,),
      )

        ],
      ),),
    );
  }

  void navigateToSignIn() {
     Firebase.initializeApp();
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => LoginPage(), fullscreenDialog: true));
  }

  void navigateToSignUp() {
    Firebase.initializeApp();
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => SignUpPage(), fullscreenDialog: true));
  }
}
