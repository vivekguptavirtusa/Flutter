import 'package:flutter/widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/setup/pages/chatbot.dart';
import 'package:flutter_app/setup/pages/Profile.dart';
import 'package:flutter_app/setup/pages/cards.dart';
import 'package:flutter_app/setup/pages/logout.dart';
import 'package:flutter_app/setup/pages/mukil.dart';
import 'package:flutter_app/setup/pages/secondscreen.dart';
import 'package:flutter_app/setup/pages/transaction.dart';
import 'package:flutter_dialogflow/flutter_dialogflow.dart';

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(' ACME BANK'),
        backgroundColor: Colors.red[600],
        centerTitle: true,
      ),
      //  Container(
      //     height: 59,
      //     width: 59,
      //     decoration: BoxDecoration(
      //       borderRadius: BorderRadius.circular(30),
      //       image: DecorationImage(
      //         image: AssetImage('assets/images/hj.jpg'),
      //       ),
      //     ),
      //   ),
      drawer: Drawer(
          child: ListView(children: <Widget>[
        DrawerHeader(
          decoration: BoxDecoration(
              gradient: LinearGradient(
                  colors: <Color>[Colors.deepOrange, Colors.orangeAccent])),
          child:Container(
            child:Column(
              children: <Widget>[
                Material(
                 // borderRadius: BorderRadius.all(Radius.circular(60.0)),
                  elevation: 10,
                  child:Padding(padding: EdgeInsets.all(5.0),
                  child:Image.asset('assets/images/acme.jpg',width: 95,height: 90,),)
                ),
                Text('ACME BANK',
                  style: TextStyle(
                    fontSize: 26.0,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2.0,
                    color: Colors.blueGrey,
                  ),  ),
              ],
            )
          )
          // child: Text(
          //   'ACME BANK',
          //   style: TextStyle(
          //     fontSize: 20.0,
          //     fontWeight: FontWeight.bold,
          //     letterSpacing: 2.0,
          //     color: Colors.lightBlue,
          //   ),
          // ),
        ),
        CustomTileList(
            Icons.person,
            'PROFILE INFO',
            () => {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Profile()))
                }),
        CustomTileList(
            Icons.person,
            'CARD INFO',
            () => {
                  Navigator.push(
                      context, MaterialPageRoute(builder: (context) => Cards()))
                }),
        CustomTileList(
            Icons.person,
            'BALANCE INFO',
            () => {
                  Navigator.push(
                      context, MaterialPageRoute(builder: (context) => Mukil()))
                }),
        CustomTileList(
            Icons.person,
            'TRANSACTION',
            () => {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Transaction()))
                }),
        CustomTileList(
            Icons.chat_bubble,
            'CHAT WITH BOT',
            () => {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => ChatBot()))
                }),
        CustomTileList(
            Icons.exit_to_app,
            'LOGOUT',
            () => {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => logout()))
                }),
      ])),
      body: Container(

        decoration: BoxDecoration(
          border:Border.all(width: 1),
          image: DecorationImage(

              image:AssetImage("assets/images/home3.jpg"),


          fit: BoxFit.cover,
        ),
        ),
      child:Column( mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,

      children: <Widget>[

        Text(
          'WELCOME TO ACME BANK',
          style: TextStyle(
            fontSize: 26.0,
            fontWeight: FontWeight.bold,
            letterSpacing: 2.0,
            color: Colors.deepOrange,
          ),
        ),
        Text('YOUR TOTAL BALANCE IS:'
              '52,300 USD',
          style: TextStyle(
            fontSize: 23.0,
            fontWeight: FontWeight.bold,
            letterSpacing: 2.0,
            color: Colors.green,
          ),
        ),
            Text('SAVING ACCOUNT AVAILABLE BALANCE:'
                  '26,100 USD',
              style: TextStyle(
                fontSize: 23.0,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
                color: Colors.blueGrey,
              ),
            ),
          ],
      ),),
      floatingActionButton: FlatButton(
        onPressed: () {
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => SecondScreen()));
        },
        child: Text('click me for next page'),
        color: Colors.green[500],
      )
    );
  }
}

class CustomTileList extends StatelessWidget {
  IconData icon;
  String text;
  Function onTap;

  CustomTileList(this.icon, this.text, this.onTap);
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8.0, 0, 8.0, 0),
      child: Container(
        decoration: BoxDecoration(
            border: Border(bottom: BorderSide(color: Colors.grey))),
        child: InkWell(
          splashColor: Colors.orange,
          onTap: onTap,
          child: Container(
            height: 50,
            child: Row(
              children: <Widget>[
                Icon(icon),
                Text(text),
                Icon(Icons.arrow_right)
              ],
            ),
          ),
        ),
      ),
    );
  }
}
