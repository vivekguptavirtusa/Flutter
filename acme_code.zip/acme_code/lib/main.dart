 import 'package:flutter/material.dart';
import 'package:flutter_app/setup/pages/welcomepage.dart';
//import 'secondscreen.dart';
//import 'setup/pages/Profile.dart';
//import 'setup/pages/cards.dart';
//import 'mukil.dart';
//import 'logout.dart';
//import 'chatbot.dart';
//import 'transaction.dart';

void main() => runApp(MaterialApp(
      home: First(),));
class First extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: WelcomePage(),
    );
  }
}
